package com.kyn.todo.broadcastreceivers;

public class Constants {
    public class TODO_ID {
    }
}

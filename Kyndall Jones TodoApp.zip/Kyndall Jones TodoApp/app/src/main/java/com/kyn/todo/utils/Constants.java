package com.kyn.todo.utils;



public class Constants {
    public static final String TODO_ID = "todo_id";
}
